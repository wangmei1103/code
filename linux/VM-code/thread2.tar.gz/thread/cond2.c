#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

pthread_cond_t cond_customer;
pthread_cond_t cond_cooker;
pthread_mutex_t mutex;

int counter = 0;//0-表示没有饭； 1-有饭
void *cooker(void *arg)
{
    while(1) {
        //加锁
        pthread_mutex_lock(&mutex);
        while(counter == 1) {
            //阻塞
            pthread_cond_wait(&cond_cooker, &mutex);
        }
        //做饭
        printf("我做了一碗饭\n");
        counter++;
        //唤醒顾客
        pthread_cond_signal(&cond_customer);
        //解锁
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}
void *customer(void *arg)
{
    while(1) {
        //加锁
        pthread_mutex_lock(&mutex);
        while(counter == 0) {
            //阻塞
            pthread_cond_wait(&cond_customer, &mutex);
        }
        //吃饭
        printf("真好吃~~~\n");
        counter--;
        //唤醒厨师
        pthread_cond_signal(&cond_cooker);
        //解锁
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}
int main (int argc, char *argv[])
{
    pthread_t tid1, tid2;
    int ret;

    pthread_cond_init(&cond_customer, NULL);
    pthread_cond_init(&cond_cooker, NULL);
    pthread_mutex_init(&mutex, NULL);
    for (int i = 0; i < 3; i++) {
        ret = pthread_create(&tid1, NULL, cooker, NULL);
        if (ret != 0) {
            printf("create thread error\n");
            return -1;
        }
    }
    for (int i = 0; i < 3; i++) {
        ret = pthread_create(&tid2, NULL, customer, NULL);
        if (ret != 0) {
            printf("create thread error\n");
            return -1;
        }
    }
    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);
    pthread_cond_destroy(&cond_cooker);
    pthread_cond_destroy(&cond_customer);
    pthread_mutex_destroy(&mutex);
    return 0;
}
