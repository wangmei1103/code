#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

pthread_cond_t cond;
pthread_mutex_t mutex;
void *thr_entry(void *arg) 
{
    while(1) {
        pthread_cond_wait(&cond, &mutex);
        printf("i am thread\n");
    }
    return NULL;
}
int main (int argc, char *argv[])
{
    pthread_t tid;
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&cond, NULL);
    int ret = pthread_create(&tid, NULL, thr_entry, NULL);
    if (ret != 0) {
        printf("thread create failed!\n");
        return -1;
    }
    while(1) {
        pthread_cond_signal(&cond);
        sleep(1);
    }
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);
    return 0;
}
