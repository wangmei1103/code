#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

void *thr_entry(void *arg)
{
    //pthread_t pthread_self(void)返回调用线程的tid
    pthread_detach(pthread_self());
    char *ptr = "中午吃什么呢？？\n";
    //char ptr[] = "中午吃什么呢？？\n";
    sleep(3);
    pthread_exit((void*)ptr);
    /*
    while(1) {
        printf("normal thread-%s\n", (char*)arg);
        sleep(1);
    }
    */
    return NULL;
}
int main (int argc, char *argv[])
{
    //pthread_create(空间-tid， 属性， 入口函数， 参数);
    pthread_t tid;
    char *ptr = "今天的天气真不错~";
    int ret = pthread_create(&tid, NULL, thr_entry, (void*)ptr);
    if (ret != 0) {
        printf("thread create failed!\n");
        return -1;
    }
    //pthread_detach(tid);
    //void *retval = NULL;
    //pthread_join(tid, &retval);
    //printf("%s\n", (char*)retval);
    while(1) {
        printf("你们想好吃什么了吗？？%p\n", tid);
        sleep(1);
    }
    return 0;
}
