#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>

int main (int argc, char *argv[])
{
    uint64_t a = 0;
    while(1) {
        a++;
    }
    return 0;
}
