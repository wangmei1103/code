#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
void sigcb(int no)
{
    printf("吃一口饭吧~先把学习放下~%d\n", no);
}
int main (int argc, char *argv[])
{
    //kill(getpid(), SIGINT);
    //raise(SIGINT);
    //alarm(3);
    //abort();
    signal(SIGINT, sigcb);
    while(1)
    {
        printf("一直学习，学习到完了吃饭???\n");
        sleep(10);
    }
    return 0;
}
