#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
int a = 0, b = 0;

int test() 
{
    a++;
    b++;
    sleep(3);
    return a+b;
}
void sigcb(int no) {
    printf("signal:%d\n", test());
}
int main (int argc, char *argv[])
{
    signal(SIGINT, sigcb);
    printf("main:%d\n", test());
    return 0;
}
