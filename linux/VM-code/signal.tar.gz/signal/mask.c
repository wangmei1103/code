#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>

void sigcb(int no)
{
    printf("recv signal:%d\n", no);
}
int main (int argc, char *argv[])
{
    signal(SIGINT, sigcb);
    signal(40, sigcb);
    sigset_t set;
    sigemptyset(&set);//清空
    sigfillset(&set);//填充
    sigprocmask(SIG_BLOCK, &set, NULL);
    printf("信号已经被阻塞，回车继续\n");
    getchar();
    sigprocmask(SIG_UNBLOCK, &set, NULL);
    while(1)sleep(1);
    return 0;
}
