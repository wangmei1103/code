#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main (int argc, char *argv[])
{
    printf("我要进行程序替换啦~~\n");
    //execl("/usr/bin/ls", "ls", "-a", "-l", NULL);
    char *arg[] = {"ls", "-a", "-l", NULL};
    char *env[] = {"MYVAL=1000", NULL};
    //extern char **environ;
    //execve("./myenv", arg, environ);
    execle("./myenv", "myenv", "-a", "-l", env);
    printf("程序替换完毕了！\n");
    return 0;
}
