#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/wait.h>

int main (int argc, char *argv[])
{
    while(1) {
        printf("[user@host path]$ ");
        fflush(stdout);
        char cmd[1024] = {0};
        fgets(cmd, 1023, stdin);
        cmd[strlen(cmd) - 1] = '\0';

        char *ptr = cmd;
        char *arg[32] = {NULL};
        int ac = 0;
        //[   ls   -a   ]
        while(*ptr != '\0') {
            if (!isspace(*ptr)) {
                arg[ac] = ptr;
                ac++;
                while(*ptr != '\0' && !isspace(*ptr)) ptr++;
                *ptr = '\0';
            }
            ptr++;
        }
        arg[ac] = NULL;

        if (strcmp(arg[0], "cd") == 0) {
            chdir(arg[1]);
            continue;
        }

        pid_t pid = fork();
        if (pid < 0) {
            continue;
        }else if (pid == 0) {
            execvp(arg[0], arg);
            exit(-1);
        }
        wait(NULL);
    }
    return 0;
}
