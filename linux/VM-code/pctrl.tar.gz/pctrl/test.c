#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv[])
{
    char *p = NULL;
    strcpy(p, "nihao");
    return 0;
}
