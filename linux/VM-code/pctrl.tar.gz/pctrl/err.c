#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv[])
{
    for(int i = 0; i <= 255; i++) {
        printf("%d-----%s\n", i, strerror(i));
    }
    return 0;
}
