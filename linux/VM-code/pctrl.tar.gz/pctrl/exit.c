#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void func() {
    _exit(257);
}
int main (int argc, char *argv[])
{
    /*
    int pid = fork();
    if (pid < 0) {
        perror("fork error");
    }
    perror("fork error");
*/
    printf("---------");
    sleep(3);
    func();
    printf("我已经退出了\n");
}
