#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv[])
{
    int pipefd[2];
    int ret = pipe(pipefd);
    if (ret < 0) {
        perror("pipe error");
        return -1;
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(-1);
    }else if (pid == 0) {
        //child
        close(pipefd[1]);
        sleep(1);
        char buf[1024] = {0};
        int ret = read(pipefd[0], buf, 1023);
        if (ret < 0) {
            perror("read error");
            return -1;
        } else if (ret == 0) {
            printf("all write closed\n");
        }
        printf("buf:%s\n", buf);
    }else {
        //parent
        close(pipefd[1]);
        sleep(100);
        int total = 0;
        char *ptr = "中午吃什么呢??\n";
        while(1) {
            int ret = write(pipefd[1], ptr, strlen(ptr));
            if (ret < 0) {
                perror("write error");
                return -1;
            }
            total += ret;
            printf("写入成功:%d\n", total);
        }
    }

    return 0;
}
