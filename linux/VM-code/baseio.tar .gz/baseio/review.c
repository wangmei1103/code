#include <stdio.h>
#include <string.h>

int main (int argc, char *argv[])
{
    //FILE * fopen(文件名，打开方式)；
    FILE *fp = fopen("test.txt", "rb+");
    if (fp == NULL) {
        perror("fopen error");
        return -1;
    }

    fseek(fp, 10, SEEK_END);

    // fwrite(数据，块大小，块个数，句柄)
    char *ptr = "今天的天气还不错~\n";
    int ret = fwrite(ptr, strlen(ptr), 1, fp);
    if (ret == 0) {
        perror("fwrite error");
        return -1;
    }

    //fseek(句柄，偏移量，偏移相对起始位置)
    fseek(fp, 0, SEEK_SET);

    char buf[1024] = {0};
    ret = fread(buf, 1, 100, fp);
    if (ret == 0) {
        if (feof(fp)) {
            printf("已经到达文件末尾\n");
        }
        if (ferror(fp)) {
            perror("读取出错");
        }
    }
    printf("%d-%s\n", ret, buf);


    fclose(fp);
    return 0;
}
