#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv[])
{
    FILE *fp = fopen("./test.txt", "rb+");
    if (fp == NULL) {
        perror("fopen error");
        return -1;
    }

    stdout->_fileno = fp->_fileno;
    printf("你好啊~~\n");

    fp->_fileno = 1;//1-标准输出的文件描述符
    char *ptr = "吃什么呢??\n";
    fwrite(ptr, strlen(ptr), 1, fp);

    fclose(fp);
    return 0;
}
