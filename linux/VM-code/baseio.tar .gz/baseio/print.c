#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

int main (int argc, char *argv[])
{
    printf("printf");
    fwrite("fwrite", 6, 1, stdout);
    write(1, "write", 5);

    sleep(3);
    return 0;
}
