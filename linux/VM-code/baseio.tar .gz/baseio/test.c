#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
extern void func()
int main (int argc, char *argv[])
{
    extern int a;
    a = 0;
    func();

    extern char **environ;
    return 0;
}
