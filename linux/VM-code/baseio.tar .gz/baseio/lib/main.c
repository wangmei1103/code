#include <stdio.h>
#include "testlib.h"

int main()
{
    testprint();
    return 0;
}
