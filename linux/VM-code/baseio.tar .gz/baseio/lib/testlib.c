#include <stdio.h>

void testprint()
{
    printf("这是一个库函数\n");
}
